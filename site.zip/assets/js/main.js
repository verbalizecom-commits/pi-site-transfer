(function () {
  const header = document.querySelector('.header');
  const body = document.body;

  // header: fundo ao rolar
  const onScroll = () => {
    const y = window.scrollY || 0;
    header.classList.toggle('header--scrolled', y > 40);
  };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  // menu mobile
  const burger = document.querySelector('.burger');
  if (burger) {
    burger.addEventListener('click', () => body.classList.toggle('menu-open'));
    document.querySelectorAll('.nav a').forEach(a => a.addEventListener('click', () => body.classList.remove('menu-open')));
  }

  // reveal on scroll
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); } });
  }, { threshold: 0.12 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));

  // tabs de plantas
  const tabs = document.querySelectorAll('.tabs button');
  tabs.forEach(btn => btn.addEventListener('click', () => {
    tabs.forEach(b => b.classList.remove('is-active'));
    document.querySelectorAll('.plan').forEach(p => p.classList.remove('is-active'));
    btn.classList.add('is-active');
    document.getElementById(btn.dataset.plan).classList.add('is-active');
  }));

  // lightbox
  const lb = document.querySelector('.lightbox');
  if (lb) {
    const img = lb.querySelector('img'), cap = lb.querySelector('.lightbox__cap');
    document.querySelectorAll('[data-zoom]').forEach(el => el.addEventListener('click', () => {
      const src = el.dataset.zoom; img.src = src; cap.textContent = el.dataset.caption || '';
      lb.classList.add('is-open'); body.style.overflow = 'hidden';
    }));
    const close = () => { lb.classList.remove('is-open'); body.style.overflow = ''; };
    lb.addEventListener('click', e => { if (e.target !== img) close(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  }

  // formulário: abre e-mail com os dados (sem backend)
  const form = document.querySelector('.form');
  if (form) form.addEventListener('submit', e => {
    e.preventDefault();
    const d = new FormData(form);
    const subject = encodeURIComponent('Contato pelo site — ' + (d.get('interesse') || 'Pacific Imperium'));
    const bodyTxt = encodeURIComponent(
      `Nome: ${d.get('nome')}\nE-mail: ${d.get('email')}\nTelefone: ${d.get('telefone')}\nInteresse: ${d.get('interesse')}\n\n${d.get('mensagem')}`);
    window.location.href = `mailto:contato@pacificimperium.com.br?subject=${subject}&body=${bodyTxt}`;
    const ok = form.querySelector('.form__ok'); if (ok) ok.style.display = 'block';
  });
})();
